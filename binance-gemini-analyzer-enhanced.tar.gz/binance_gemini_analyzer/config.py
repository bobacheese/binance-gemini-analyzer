# Untuk testing, gunakan environment variable atau ganti dengan API key yang valid
import os
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'demo_key_for_testing')

